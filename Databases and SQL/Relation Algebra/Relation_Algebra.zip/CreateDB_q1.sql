 CREATE TABLE Buyers (
	bId INTEGER PRIMARY KEY,
	name VARCHAR(10),
	address VARCHAR(50),
	tel VARCHAR(50)
);

CREATE TABLE Realtors (
	rId INTEGER PRIMARY KEY,
	name VARCHAR(50),
	address VARCHAR(50),
	tel VARCHAR(20), 
	years INTEGER
);

CREATE TABLE Houses (
	address VARCHAR(50) PRIMARY KEY,
	type VARCHAR(50),
	size float,
	rAmount float, 
	rId INTEGER,
	percentage float,
	status VARCHAR(50),
	FOREIGN KEY (rId) REFERENCES Realtors(rId),
	CONSTRAINT CHK_TYPE CHECK (type = 'private' OR type = 'dual')
);

CREATE TABLE Features (
	address VARCHAR(50),
	feature VARCHAR(50),
	value VARCHAR(200),
	FOREIGN KEY (address) REFERENCES Houses(address),
	CONSTRAINT PRM_KEY1 primary key (address, feature)
);


CREATE TABLE Sales  (
	sId INTEGER PRIMARY KEY,
	address VARCHAR(50) NOT NULL,
	sAmount float,
	bId INTEGER,
	sdate TIMESTAMP,
	FOREIGN KEY (address) REFERENCES Houses(address),
	FOREIGN KEY (bId) REFERENCES Buyers(bId) ON DELETE CASCADE
);

CREATE TABLE Visits (
	bId INTEGER,
	address VARCHAR(50),
	rId INTEGER,
	vdate TIMESTAMP,
	CONSTRAINT PRM_KEY2 primary key (bId, address, rId),
	FOREIGN KEY (rId) REFERENCES Realtors(rId),
	FOREIGN KEY (address) REFERENCES Houses(address),
	FOREIGN KEY (bId) REFERENCES Buyers(bId) ON DELETE CASCADE
);