-- A

SELECT s.address
FROM Sales AS s
EXCEPT
SELECT s1.address
FROM Sales AS s1
LEFT OUTER JOIN Visits AS v
USING(bid)
WHERE v.address = s1.address AND v.vdate <= s1.sdate;

-- B

SELECT b.bid, b.name
FROM Buyers AS b
LEFT OUTER JOIN Visits AS v1
USING(bid)
LEFT OUTER JOIN Visits AS v2
USING(bid)
WHERE(
v1.bid = v2.bid AND v1.address = v2.address AND v1.rid <> v2.rid)
group by bid;


-- C

SELECT b.bid, b.name, b.address, b.tel
FROM Buyers AS b
Join visits on (b.bid=visits.bid) 
Where b.bid not in (Select bid from sales)
Group by b.bid, b.name, b.address, b.tel
Having count(distinct visits.address)>=10;

-- D

SELECT r.rid, r.name
FROM (SELECT v.rid, v.vdate
FROM Visits AS v
WHERE extract(year FROM v.vdate) <> 2013 AND extract(month FROM v.vdate) <> 11) AS v
LEFT OUTER JOIN Realtors AS r
USING(rid)
GROUP BY r.rid, r.name
HAVING COUNT(*)>= ALL (
SELECT COUNT(*) FROM Visits WHERE extract(year FROM Visits.vdate) <> 2013 AND extract(month FROM Visits.vdate) <> 11
GROUP BY r.rid);