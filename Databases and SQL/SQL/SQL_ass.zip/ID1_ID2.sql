CREATE TABLE Project (

);

CREATE TABLE Materials (

);

CREATE TABLE Inspector (

);

CREATE TABLE ProjectMaterials (

);

CREATE TABLE Inspection (

);



